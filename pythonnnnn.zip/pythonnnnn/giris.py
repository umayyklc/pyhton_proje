from customtkinter import *
import json
import subprocess
import customtkinter as ctk

# Kullanıcı verilerinin kaydedileceği dosya
FILE_NAME = "user_data.json"

# Kullanıcı verilerini JSON dosyasından yükler
def load_users():
    try:
        # kullanıcı verilerini yükler
        with open(FILE_NAME, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

# Kullanıcı verilerini JSON dosyasına kaydeder
def save_users(users):
    with open(FILE_NAME, 'w') as file:
        json.dump(users, file, indent=4)

# Popup penceresini gösterir
def show_popup(message, color):
    popup = ctk.CTkToplevel() 
    popup.title("Bilgi") 
    popup.geometry("300x150") 
    popup.resizable(False, False)
    popup.configure(fg_color="#242424") 
    
    textColor = color
    label = ctk.CTkLabel(popup, text=message, text_color= textColor, font=("Arial", 14))
    label.pack(pady=(30, 10)) 

    button = ctk.CTkButton(popup, text="Tamam", command=popup.destroy,
                           fg_color="#3e9e5f", hover_color="#3e9e5f",
                           text_color="white", font=("Arial", 12))
    button.pack(pady=(10, 20))
    popup.attributes("-topmost", True)

# Kayıt ekranı
def register():
    def register_user():
        # Kullanıcı adı ve şifre bilgileri
        username = username_entry.get()
        password = password_entry.get()

        if not username or not password:
            show_popup("Tüm alanları doldurun!", "red")
            return

        # Kullanıcı verilerini alır
        users = load_users()

        # aynı kullanıcı adı daha önce kayıt olmuş ise hata verir
        if username in users:
            show_popup("Kullanıcı zaten mevcut!", "red")
        else:
            # Yeni kullanıcıyı kaydeder
            users[username] = password
            # kullanıcı verilerini kayıt etmek için fonksiyona gönderir
            save_users(users)
            
            show_popup("Kayıt başarılı!", "green")
            show_login_screen()

    # Kayıt ekranından çıkışı sağlar
    def cancel_registration():
        show_login_screen()

    # Kayıt ekranı oluşturma
    for widget in main_frame.winfo_children():
        widget.destroy()

    login_label = CTkLabel(main_frame, text="Kayıt Ol", font=("Arial", 24, "bold"))
    login_label.grid(row=0, column=0, columnspan=2, pady=30)

    # Kullanıcı adı ve şifre girişleri
    username_label = CTkLabel(main_frame, text="Kullanıcı Adı:", font=("Helvetica", 14, "bold"))
    username_label.grid(row=1, column=0, padx=20, pady=15, sticky="e")
    username_entry = CTkEntry(main_frame, font=("Arial", 14), width=250)
    username_entry.grid(row=1, column=1, padx=20, pady=15, sticky="w")

    password_label = CTkLabel(main_frame, text="Şifre:", font=("Helvetica", 14, "bold"))
    password_label.grid(row=2, column=0, padx=20, pady=15, sticky="e")
    password_entry = CTkEntry(main_frame, font=("Arial", 14), show="*", width=250)
    password_entry.grid(row=2, column=1, padx=20, pady=15, sticky="w")


    CTkButton(main_frame, text="Kaydol", font=("Arial", 14), command=register_user).grid(row=3, column=0, columnspan=2, pady=20)
    CTkButton(main_frame, text="İptal", font=("Arial", 14), command=cancel_registration).grid(row=4, column=0, columnspan=2, pady=10)

# Giriş işlemini gerçekleştirir
def login(username_entry, password_entry):
    username = username_entry.get()
    password = password_entry.get()

    # Kullanıcı verilerini yükler
    users = load_users()

    # Giriş bilgilerini kontrol eder
    if username in users and users[username] == password:
        show_popup("Giriş başarılı!", "green")
        root.destroy()  # Ana pencereyi kapatır
        subprocess.run(["python", "PythonProje1.py"])  # Ana sayfayı açar
    else:
        show_popup("Hatalı kullanıcı adı veya şifre!", "red")

# Giriş ekranını oluşturur
def show_login_screen():
    for widget in main_frame.winfo_children():
        widget.destroy()

    login_label = CTkLabel(main_frame, text="Giriş Yap", font=("Arial", 24, "bold"))
    login_label.grid(row=0, column=0, columnspan=2, pady=30)

    # Kullanıcı adı ve şifre giriş alanları
    username_label = CTkLabel(main_frame, text="Kullanıcı Adı:", font=("Helvetica", 14, "bold"))
    username_label.grid(row=1, column=0, padx=20, pady=15, sticky="e")
    username_entry = CTkEntry(main_frame, font=("Arial", 14), width=250)
    username_entry.grid(row=1, column=1, padx=20, pady=15, sticky="w")

    password_label = CTkLabel(main_frame, text="Şifre:", font=("Helvetica", 14, "bold"))
    password_label.grid(row=2, column=0, padx=20, pady=15, sticky="e")
    password_entry = CTkEntry(main_frame, font=("Arial", 14), show="*", width=250)
    password_entry.grid(row=2, column=1, padx=20, pady=15, sticky="w")

    # Giriş yap ve kayıt ol butonları
    CTkButton(main_frame, text="Giriş Yap", font=("Arial", 14), command=lambda: login(username_entry, password_entry)).grid(row=3, column=0, columnspan=2, pady=20)
    CTkButton(main_frame, text="Kayıt Ol", font=("Arial", 14), command=register).grid(row=4, column=0, columnspan=2, pady=10)

# Ana pencere oluşturulur
root = CTk()
root.title("Giriş")
root.geometry("800x500") 


main_frame = CTkFrame(root, width=400, height=350, corner_radius=20, border_width=2)
main_frame.place(relx=0.5, rely=0.5, anchor="center")
main_frame.configure(fg_color=("#f7f7f7", "#333333"))
ctk.set_default_color_theme("green")
show_login_screen()
ctk.set_appearance_mode("Dark")
root.mainloop()
