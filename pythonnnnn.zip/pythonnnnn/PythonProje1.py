import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
import json
import subprocess




# JSON dosya yolu
data_file = "data.json"

# Veriyi yükleme ve kaydetme fonksiyonları
def load_data():
    try:
        with open(data_file, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def save_data(data):
    with open(data_file, "w") as file:
        json.dump(data, file, indent=4)

# Ana Uygulama Sınıfı
class MovieApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Pencere ayarları
        self.title("Film/Dizi Takip Sistemi")
        self.geometry("1000x600")
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("green")

        # Veriler
        self.data = load_data()

        # Sayfa çerçevesi
        self.frames = {}
        for Page in (HomePage, AddPage, DetailPage):
            frame = Page(self)
            self.frames[Page] = frame
            frame.place(relx=0, rely=0, relwidth=1, relheight=1)

        self.show_frame(HomePage)

    def show_frame(self, page):
        frame = self.frames[page]
        frame.tkraise()

class HomePage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent)

        # Başlık
        self.label = ctk.CTkLabel(self, text="Ana Sayfa", font=("Arial", 24, "bold"))
        self.label.place(relx=0.5, rely=0.05, anchor="center")

        # Arama ve Filtreleme Alanı
        search_frame = ctk.CTkFrame(self)
        search_frame.place(relx=0.1, rely=0.1, relwidth=0.8, relheight=0.1)

        self.search_var = tk.StringVar()
        self.search_entry = ctk.CTkEntry(search_frame, textvariable=self.search_var, placeholder_text="Film/Dizi Ara")
        self.search_entry.place(relx=0.02, rely=0.2, relwidth=0.45)

        self.search_button = ctk.CTkButton(search_frame, text="Ara", command=self.search)
        self.search_button.place(relx=0.48, rely=0.2, relwidth=0.1)

        #  filtreleme butonları (Dizi ve Film)
        self.filter_film_button = ctk.CTkButton(search_frame, text="Film", command=lambda: self.filter("Film"))
        self.filter_film_button.place(relx=0.60, rely=0.2, relwidth=0.1)

        self.filter_series_button = ctk.CTkButton(search_frame, text="Dizi", command=lambda: self.filter("Dizi"))
        self.filter_series_button.place(relx=0.72, rely=0.2, relwidth=0.1)

        self.filter_var = tk.StringVar(value="Tümü")
        self.filter_menu = ctk.CTkOptionMenu(search_frame, variable=self.filter_var, values=["Tümü", "İzlendi", "İzlenecek", "Bekliyor", "Favoriler"], command=self.filter)
        self.filter_menu.place(relx=0.84, rely=0.2, relwidth=0.15)

         # Liste Bölümü
        self.listbox = tk.Listbox(self, 
                                  font=("Courier New", 17, "bold"), 
                                  background="#2e2e2e", 
                                  fg="#ffffff",  # Yazı rengi beyaz
                                  bd=0, 
                                  highlightthickness=0)  # Focus olduğunda kenarlık oluşmaması için
        self.listbox.place(relx=0.1, rely=0.22, relwidth=0.8, relheight=0.5)
        self.listbox.bind("<Double-1>", self.open_detail_page)

        # Sayfa geçiş butonları
        button_frame = ctk.CTkFrame(self)
        button_frame.place(relx=0.1, rely=0.75, relwidth=0.8, relheight=0.1)

        self.to_add_button = ctk.CTkButton(button_frame, text="Içerik Ekle", command=self.reset_and_go_add, width=120)
        self.to_add_button.place(relx=0.20, rely=0.2)


        # Favorilere Ekle butonu
        self.add_to_favorites_button = ctk.CTkButton(button_frame, text="Favorilere Ekle",command=self.add_to_favorites, width=120)
        self.add_to_favorites_button.place(relx=0.4, rely=0.2)

        # favorilerden kaldır butonu
        self.remove_to_favorites_button = ctk.CTkButton(button_frame, text="Favorilerden Sil", command=self.remove_to_favorites, width=120)
        self.remove_to_favorites_button.place(relx=0.4, rely=0.2)
        self.remove_to_favorites_button.place_forget()
        

        # Sil butonu
        self.delete_button = ctk.CTkButton(button_frame, text="Sil", command=self.delete_movie, width=120)
        self.delete_button.place(relx=0.6, rely=0.2)

        self.refresh_list()


        #oturumu kapat butonu
        self.back_button = ctk.CTkButton(self, text= "Oturumu Kapat", width=50, command=self.backLogin)
        self.back_button.place(relx=0.01, rely=0.03)


    def refresh_list(self, data=None):
        self.listbox.delete(0, tk.END)
        data = data if data is not None else self.master.data
        for item in data:
            name = item['name']
            rating = item.get('rating', 0)  # Puan bilgisi
            status = item.get('status', 'İzlenecek')  # Durum bilgisi
            notes = item.get('notes', "")
            
            # temel bilgi ekleniyor
            list_item = f"{name} | durum: {status} "
            
            # Puan ve not bilgisi varsa ekleniyor
            if rating or notes:
                list_item += f"| puan:{rating} | not: {notes}"

            self.listbox.insert(tk.END, list_item)

            self.filter_var.set("Tümü")



    def search(self):
        query = self.search_var.get().strip().lower()
        filtered_data = []
        
        # Filtreye uygun verileri seç
        for item in self.master.data:
            if query in item['name'].lower() or query in item['type'].lower():
                filtered_data.append(item)
        

        self.refresh_list(filtered_data)


    def filter(self, choice):
        self.listbox.delete(0, tk.END)
        for item in self.master.data:
            name = item['name']
            rating = item.get('rating', 0)
            status = item.get('status', 'İzlenecek')
            notes = item.get('notes', "")
            
            # Puan ve not değerini boş değilse ekle
            rating_display = f"| puanı: {rating}" if rating else ""
            notes_display = f"not: {notes}" if notes else ""
            
            # Filtreleme işlemi
            if choice == "Tümü" or (
                choice == "Film" and item['type'].lower() == "film"
            ) or (
                choice == "Dizi" and item['type'].lower() == "dizi"
            ) or (
                choice == "İzlendi" and item['status'].lower() == "izlendi"
            ) or (
                choice == "İzlenecek" and item['status'].lower() == "izlenecek"
            ) or (
                choice == "Bekliyor" and item['status'].lower() == "bekleniyor"
            ) or (
                choice == "Favoriler" and item.get('favorite', False)
            ):
                # Puan ve not boş değilse ekle
                self.listbox.insert(tk.END, f"{name} | durum: {status} {rating_display} {notes_display}")




        # Favoriler seçildiyse butonu göster, değilse gizle
        if choice == "Favoriler":
            self.add_to_favorites_button.place_forget()
            self.remove_to_favorites_button.place(relx=0.4, rely=0.2)
            
        else:
            self.remove_to_favorites_button.place_forget()
            self.add_to_favorites_button.place(relx=0.4, rely=0.2)

    def open_detail_page(self, event):
        selection = self.listbox.curselection()
        if selection:
            index = selection[0]
            self.master.frames[DetailPage].load_item(self.master.data[index])
            self.master.show_frame(DetailPage)


    def reset_and_go_add(self):
        self.search_var.set("")
        self.master.frames[AddPage].reset_fields()
        self.master.show_frame(AddPage)

    def add_to_favorites(self):
        selection = self.listbox.curselection()
        if selection:
            index = selection[0]
            item = self.master.data[index]
            
            if item.get('favorite', False):  # Eğer öğe zaten favorilerdeyse
                messagebox.showwarning("Uyarı", "Bu içerik zaten favorilerde.")
            else:
                item['favorite'] = True  # Favorilere ekle
                self.refresh_list()
                messagebox.showinfo("Başarı", "İçerik başarıyla favorilere eklendi.")
        else:
            messagebox.showerror("Hata", "Lütfen bir seçim yapın.")



    def remove_to_favorites(self):
        selection = self.listbox.curselection()
        if selection:
            index = selection[0]
            # Veriyi değiştir
            self.master.data[index]['favorite'] = False
            # Değişiklikleri kaydet
            save_data(self.master.data)
            # Listeyi yenile
            self.refresh_list()
            messagebox.showinfo("Başarı", "İçerik başarıyla favorilerden kaldırıldı.")
        else:
            messagebox.showerror("Hata", "Lütfen bir seçim yapın.")





    def delete_movie(self):
        selection = self.listbox.curselection()
        if selection:
            index = selection[0]
            confirmation = messagebox.askyesno("Silme Onayı", "Seçili filmi silmek istediğinizden emin misiniz?")
            if confirmation:
                # Seçilen öğeyi sil
                self.master.data.pop(index)
                # Veriyi kaydet
                save_data(self.master.data)
                # Listeyi yenile
                self.refresh_list()
        else:
            messagebox.showerror("Hata", "Lütfen bir seçim yapın.")


    def backLogin(self):
        self.master.destroy()
        subprocess.run(["python", "giris.py"])  # Yeni dosyayı çalıştır

class DetailPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent)

        # Başlık
        self.label = ctk.CTkLabel(self, text="Detay Sayfası", font=("Helvetica Neue", 24, "bold"))
        self.label.place(relx=0.5, rely=0.05, anchor="center")

        # Puanlama
        self.rating_var = tk.IntVar()
        ctk.CTkLabel(self, text="Puan:", font=("Helvetica Neue", 14)).place(relx=0.05, rely=0.2)
        self.rating_slider = ctk.CTkSlider(self, from_=1, to=10, variable=self.rating_var, command=self.update_rating_label)
        self.rating_slider.place(relx=0.2, rely=0.2, relwidth=0.6)
        self.rating_label = ctk.CTkLabel(self, text="0", font=("Helvetica Neue", 14))
        self.rating_label.place(relx=0.9, rely=0.2, anchor="e")

        # Notlar
        self.notes_var = tk.StringVar()
        ctk.CTkLabel(self, text="Notlar:", font=("Helvetica Neue", 14)).place(relx=0.05, rely=0.35)
        self.notes_entry = ctk.CTkEntry(self, textvariable=self.notes_var)
        self.notes_entry.place(relx=0.2, rely=0.35, relwidth=0.75)

        # İzlenme Durumu
        self.status_var = tk.StringVar(value="izlenecek")
        ctk.CTkLabel(self, text="Durum:", font=("Helvetica Neue", 14)).place(relx=0.05, rely=0.5)
        self.status_menu = ctk.CTkOptionMenu(self, variable=self.status_var, values=["izlendi", "izlenecek", "bekleniyor"])
        self.status_menu.place(relx=0.2, rely=0.5, relwidth=0.75)

        # Kaydet Butonu
        self.save_button = ctk.CTkButton(self, text="Kaydet", command=self.save_changes)
        self.save_button.place(relx=0.35, rely=0.75, relwidth=0.3)

        # Geri Dönüş Butonu
        self.back_button = ctk.CTkButton(self, text="Ana Sayfa", command=lambda: parent.show_frame(HomePage))
        self.back_button.place(relx=0.35, rely=0.85, relwidth=0.3)

    def update_rating_label(self, value):
        self.rating_label.configure(text=f"{int(float(value))}")

    def load_item(self, item):
        self.item = item
        self.rating_var.set(item.get("rating", 0))
        self.notes_var.set(item.get("notes", ""))
        self.status_var.set(item.get("status", "izlenecek"))

    def save_changes(self):
        self.item["rating"] = self.rating_var.get()
        self.item["notes"] = self.notes_var.get()
        self.item["status"] = self.status_var.get()
        save_data(self.master.data)
        self.master.frames[HomePage].refresh_list()
        self.master.show_frame(HomePage)





# Film/Dizi Ekleme Sayfası
class AddPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent)

        
        self.label = ctk.CTkLabel(self, text="İçerik Ekle", font=("Helvetica Neue", 24, "bold"))
        self.label.place(relx=0.5, rely=0.05, anchor="center")

        
        self.name_var = tk.StringVar()
        self.type_var = tk.StringVar(value="film")
        self.status_var = tk.StringVar(value="izlenecek")

        form_frame = ctk.CTkFrame(self)
        form_frame.place(relx=0.1, rely=0.15, relwidth=0.8, relheight=0.5)

        ctk.CTkLabel(form_frame, text="Ad:", font=("Helvetica Neue", 14)).place(relx=0.02, rely=0.1)
        ctk.CTkEntry(form_frame, textvariable=self.name_var).place(relx=0.2, rely=0.1, relwidth=0.75)

        ctk.CTkLabel(form_frame, text="Tür:", font=("Helvetica Neue", 14)).place(relx=0.02, rely=0.3)
        ctk.CTkOptionMenu(form_frame, variable=self.type_var, values=["film", "dizi"]).place(relx=0.2, rely=0.3, relwidth=0.75)

        ctk.CTkLabel(form_frame, text="Durum:", font=("Helvetica Neue", 14)).place(relx=0.02, rely=0.5)
        ctk.CTkOptionMenu(form_frame, variable=self.status_var, values=["izlendi", "izlenecek", "bekleniyor"]).place(relx=0.2, rely=0.5, relwidth=0.75)

        # Kaydet Butonu
        self.save_button = ctk.CTkButton(self, text="Kaydet", command=self.save_item)
        self.save_button.place(relx=0.4, rely=0.7, relwidth=0.2)

        # Ana sayfaya dönüş butonu
        self.back_button = ctk.CTkButton(self, text="Ana Sayfa", command=lambda: parent.show_frame(HomePage))
        self.back_button.place(relx=0.4, rely=0.8, relwidth=0.2)

    def save_item(self):
        new_item = {
            "name": self.name_var.get(),
            "type": self.type_var.get(),
            "status": self.status_var.get(),
            "rating": 0,
            "notes": "",
            "favorite": False
        }

        if not new_item["name"]:
            messagebox.showerror("Hata", "Ad alanı boş bırakılamaz!")
            return

        self.master.data.append(new_item)
        save_data(self.master.data)
        self.master.frames[HomePage].refresh_list()
        self.master.show_frame(HomePage)
        self.reset_fields()

    def reset_fields(self):
        self.name_var.set("")
        self.type_var.set("film")
        self.status_var.set("izlenecek")

# Uygulama Başlatma
if __name__ == "__main__":
    app = MovieApp()
    app.mainloop()
